// Base URL configuration for backend API
// Android Emulator: 10.0.2.2 points to host machine.
// iOS Simulator: use http://127.0.0.1:3001 (or your machine IP on device).
//
// Not: Backend bu projede port 3001'de çalışıyor.
const String apiBaseUrl = 'http://10.0.2.2:3001';


